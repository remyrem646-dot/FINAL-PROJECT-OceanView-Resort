# Fey's Guestbook (Week 13: Django Views & Form Handling)

A CSRF-protected guestbook built with a Django ModelForm.

## Folder contents

```
guestbook/
  __init__.py
  admin.py
  apps.py
  forms.py        <- EntryForm (ModelForm)
  models.py       <- Entry model
  urls.py
  views.py        <- guestbook view (GET/POST branching)
  templates/guestbook/guestbook.html   <- template with {% csrf_token %}
```

Copy the whole `guestbook` folder into `groceries_project/` (next to `manage.py` and `inventory`).

## Setup

1. In `groceries_project/settings.py`, add the app:

```python
INSTALLED_APPS = [
    # ...the defaults...
    'inventory',
    'guestbook',   # <-- add this
]
```

2. In `groceries_project/groceries_project/urls.py`:

```python
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('guestbook.urls')),
]
```

3. In the terminal (with `(env)` active, inside the folder that has `manage.py`):

```bash
python manage.py makemigrations guestbook
python manage.py migrate
python manage.py runserver
```

Look for `Create model Entry` and `Applying guestbook.0001_initial... OK`.
Then open http://127.0.0.1:8000/

## Test it

1. Invalid: submit with both fields blank -> page re-renders with red error messages.
2. Invalid: message "Hi" -> "too short" error from `clean_message`.
3. Valid: real name + message -> green "Thank you" notice and the entry appears in the list.
4. Check http://127.0.0.1:8000/admin -> **Entries** shows the saved row.
   (Use `python manage.py createsuperuser` if you need a login.)

## Screenshots for the PDF (one PDF, title under each)

| # | Screenshot | Title |
|---|---|---|
| 1 | forms.py | Figure 1. EntryForm (forms.py) |
| 2 | views.py | Figure 2. Guestbook View (views.py) |
| 3 | guestbook.html showing {% csrf_token %} | Figure 3. Template with CSRF Protection |
| 4 | Page after blank submission, showing errors | Figure 4. Validation Errors on Blank Submission |
| 5 | Page after valid entry, showing green notice | Figure 5. Valid Entry Shown on the Guestbook |
| 6 | Admin Entries list | Figure 6. Entry Saved in Django Admin |
| extra | models.py | Figure 7. Entry Model (models.py) |

## Form Security Checklist

Draft based on this week's task. Match it to your professor's version if it differs.

| # | Check | Done | Where |
|---|---|---|---|
| 1 | Form uses method="post" for data submission | [x] | guestbook.html |
| 2 | {% csrf_token %} is inside the form | [x] | guestbook.html |
| 3 | ModelForm tied to the model, exposing only needed fields | [x] | forms.py |
| 4 | form.is_valid() runs before form.save() | [x] | views.py |
| 5 | request.POST is never used directly, only the bound form | [x] | views.py |
| 6 | Blank required fields are rejected and errors are shown | [x] | Figure 4 |
| 7 | Custom validation rejects too-short messages | [x] | clean_message in forms.py |
| 8 | Field lengths capped with max_length | [x] | models.py |
| 9 | Successful POST redirects (prevents double-submit on refresh) | [x] | redirect('guestbook') in views.py |
| 10 | Template auto-escapes output (helps against XSS) | [x] | Django default |
| 11 | Saved entries verified in the database | [x] | Admin, Figure 6 |
