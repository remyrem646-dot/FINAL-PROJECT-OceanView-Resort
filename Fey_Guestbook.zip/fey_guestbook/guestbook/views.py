from django.contrib import messages
from django.shortcuts import redirect, render

from .forms import EntryForm
from .models import Entry


def guestbook(request):
    if request.method == 'POST':
        form = EntryForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Thank you for signing Fey's guestbook! 🌸")
            return redirect('guestbook')
    else:
        form = EntryForm()

    entries = Entry.objects.all()
    return render(request, 'guestbook/guestbook.html', {'form': form, 'entries': entries})
