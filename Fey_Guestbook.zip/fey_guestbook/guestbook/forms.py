from django import forms
from .models import Entry


class EntryForm(forms.ModelForm):
    class Meta:
        model = Entry
        fields = ['name', 'message']
        labels = {
            'name': 'Your name ✨',
            'message': 'Leave a little message 💌',
        }
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'e.g. Maria Clara'}),
            'message': forms.Textarea(attrs={
                'placeholder': 'Write something kind for Fey...',
                'rows': 4,
            }),
        }

    def clean_message(self):
        message = self.cleaned_data['message'].strip()
        if len(message) < 5:
            raise forms.ValidationError(
                "Your message is a bit too short. Add at least 5 characters!"
            )
        return message
